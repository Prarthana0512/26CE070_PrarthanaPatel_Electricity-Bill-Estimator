function calculateBill() {
    const units = Number(document.getElementById("units").value) ;
    const consumerType = document.getElementById("consumerType").value;
    const rate = chooseRate(units);
    const baseAmount = calculateBase(units, rate);
    const surchargePercent = consumerType === "Commercial" ? 10 : 0;
    const surcharge = calculateSurcharge(baseAmount, surchargePercent);
    const fixedCharge = 50;
    const total = baseAmount + surcharge + fixedCharge;
    document.getElementById("result").textContent = "Rate: ₹" + rate + "/unit | Base: ₹" + baseAmount + " | Surcharge: ₹" + surcharge + " | Fixed: ₹" + fixedCharge + " | Total: ₹" + total;
    document.getElementById("breakdown").textContent = buildExamples();
}

function calculateSurcharge(amount, percentage) {
    // TODO M6: Calculate the surcharge as a percentage of base amount.
    return amount * percentage / 100;
}

function chooseRate(units) {
    // TODO D1: Use if / else if / else: 1-100=>5, 101-300=>7, above 300=>9.
    if (units <= 100) {
        return 5;
    } else if (units <= 300) {
        return 7;
    } else {
        return 9;
    }
}

function calculateBase(units, rate) {
    // TODO D2: Return the base electricity bill.
    return units * rate;
}

function buildExamples() {
    // TODO D3: Use a for loop for 100, 200, 300, 400, 500 units.
    // For each value, show its base bill using chooseRate() and calculateBase().
    const exampleUnits = [100, 200, 300, 400, 500];
    let output = "";

    for (let i = 0; i < exampleUnits.length; i++) {
        const units = exampleUnits[i];
        const rate = chooseRate(units);
        const base = calculateBase(units, rate);
        output += units + " units = ₹" + base + "\n";
    }

    return output.trim();
    return "Complete the electricity consumption examples.";
}
